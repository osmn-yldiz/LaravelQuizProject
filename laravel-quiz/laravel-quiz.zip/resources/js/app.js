import './bootstrap';

import 'jquery';
import $ from 'jquery'
window.jQuery = $;
window.$ = $;

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
