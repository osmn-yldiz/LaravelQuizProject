<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> <?php echo e($question->question); ?> Soru Düzenle <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-body">
            <div class="float-end mb-2"><a href="<?php echo e(route('questions.index', $question->quiz_id)); ?>"
                                           class="btn btn-primary btn-md"><i
                        class="fa-solid fa-arrow-left"></i> Geri
                    Dön</a></div>
            <form method="POST" action="<?php echo e(route('questions.update', [$question->quiz_id,$question->id])); ?>"
                  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Soru</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"
                              name="question"><?php echo e($question->question); ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="formFile" class="form-label">Fotoğraf</label>
                    <?php if($question->image): ?>
                        <a href="<?php echo e(asset($question->image)); ?>" target="_blank">
                            <img src="<?php echo e(asset($question->image)); ?>" class="img-responsive" style="width: 200px;">
                        </a>
                    <?php endif; ?>
                    <input class="form-control" type="file" id="formFile" name="image">
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">1. Cevap</label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="2"
                                      name="answer1"><?php echo e($question->answer1); ?></textarea>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">2. Cevap</label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="2"
                                      name="answer2"><?php echo e($question->answer2); ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">3. Cevap</label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="2"
                                      name="answer3"><?php echo e($question->answer3); ?></textarea>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">4. Cevap</label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="2"
                                      name="answer4"><?php echo e($question->answer4); ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Doğru Cevap</label>
                    <select class="form-select" aria-label="Default select example" name="correct_answer">
                        <option selected>Doğru Seçeneği Seçiniz...</option>
                        <option <?php if($question->correct_answer === 'answer1'): ?> selected <?php endif; ?> value="answer1">1. Cevap
                        </option>
                        <option <?php if($question->correct_answer === 'answer2'): ?> selected <?php endif; ?> value="answer2">2. Cevap
                        </option>
                        <option <?php if($question->correct_answer === 'answer3'): ?> selected <?php endif; ?> value="answer3">3. Cevap
                        </option>
                        <option <?php if($question->correct_answer === 'answer4'): ?> selected <?php endif; ?> value="answer4">4. Cevap
                        </option>
                    </select>
                </div>

                <div class="d-grid gap-2 col-2 mx-auto">
                    <button class="btn btn-success btn-md" style="background-color: #198754" type="submit">Soru
                        Güncelle
                    </button>
                </div>

            </form>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\osman\laravel-quiz\resources\views/admin/question/edit.blade.php ENDPATH**/ ?>