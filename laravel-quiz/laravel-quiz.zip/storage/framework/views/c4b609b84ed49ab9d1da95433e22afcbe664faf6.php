<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e($quiz->title); ?> Quizine ait Sorular
     <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-body">
            <div class="card-title">

                <a href="<?php echo e(route('questions.create',$quiz->id)); ?>" class="btn btn-md btn-primary"><i
                        class="fa-solid fa-plus"></i>
                    Soru Oluştur</a>

                <div class="float-end mb-2"><a href="<?php echo e(route('quizzes.index')); ?>" class="btn btn-primary btn-md"><i
                            class="fa-solid fa-arrow-left"></i> Geri
                        Dön</a></div>
            </div>

            <table class="table table-bordered table-sm">
                <thead>
                <tr>
                    <th scope="col">Soru</th>
                    <th scope="col">Fotoğraf</th>
                    <th scope="col">1. Cevap</th>
                    <th scope="col">2. Cevap</th>
                    <th scope="col">3. Cevap</th>
                    <th scope="col">4. Cevap</th>
                    <th scope="col">Doğru Cevap</th>
                    <th scope="col" style="width: 80px;">İşlemler</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $quiz->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($question->question); ?></td>
                        <td>
                            <?php if($question->image): ?>
                                <a href="<?php echo e(asset($question->image)); ?>" class="btn btn-sm btn-light" target="_blank">Görüntüle</a>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($question->answer1); ?></td>
                        <td><?php echo e($question->answer2); ?></td>
                        <td><?php echo e($question->answer3); ?></td>
                        <td><?php echo e($question->answer4); ?></td>
                        <td><span class="badge rounded-pill bg-success text-light"><?php echo e(Str::substr($question->correct_answer, -1)); ?>. Cevap</span></td>
                        <td>
                            <a href="<?php echo e(route('questions.edit',[$quiz->id,$question->id])); ?>"
                               class="btn btn-sm btn-warning"><i
                                    class="fa-solid fa-pen-to-square"></i></a>
                            <a href="<?php echo e(route('questions.destroy', [$quiz->id, $question->id])); ?>" class="btn btn-sm btn-danger"><i
                                    class="fa-solid fa-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\osman\laravel-quiz\resources\views/admin/question/list.blade.php ENDPATH**/ ?>