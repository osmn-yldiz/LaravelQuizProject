<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> <?php echo e($quiz->title); ?> Sonucu <?php $__env->endSlot(); ?>

    <div class="card">
        <div class="card-body">

            <p class="fs-1">Puan: <span class="fw-bold"><?php echo e($quiz->my_result->point); ?></span></p>

            <div class="alert bg-light" role="alert">
                <i class="fa-solid fa-circle-dot text-dark"></i> İşaretlediğin Şık<br>
                <i class="fa-solid fa-check text-success"></i> Doğru Cevap<br>
                <i class="fa-solid fa-xmark text-danger"></i> Yanlış Cevap
            </div>

            <ol class="list-group list-group-numbered">
                <?php $__currentLoopData = $quiz->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between align-items-start">
                        <div class="ms-2 me-auto">

                            <div class="d-inline-flex">
                                <div class="fw-bold"><?php echo e($question->question); ?></div>

                                <?php if($question->correct_answer === $question->my_answer->answer): ?>
                                    <i class="fa-solid fa-check fa-2x text-success ml-2"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-xmark fa-2x text-danger ml-2"></i>
                                <?php endif; ?>
                            </div>

                            <?php if($question->image): ?>
                                <img src="<?php echo e(asset($question->image)); ?>" class="img-fluid"
                                     alt="<?php echo e($question->question); ?>" width="25%">
                            <?php endif; ?>

                            <br>
                            <small class="text-capitalize text-dark text-bg-light">Bu soruya <strong
                                    class="text-decoration-underline">%<?php echo e($question->true_percent); ?></strong>
                                oranında doğru cevap verildi.</small>

                            <div class="form-check mt-2">
                                <?php if("answer1" === $question->correct_answer): ?>
                                    <i class="fa-solid fa-check text-success"></i>
                                <?php elseif("answer1" === $question->my_answer->answer): ?>
                                    <i class="fa-solid fa-circle-dot"></i>
                                <?php endif; ?>
                                <label class="form-check-label" for="quiz<?php echo e($question->id); ?>1">
                                    <?php echo e($question->answer1); ?>

                                </label>
                            </div>

                            <div class="form-check">
                                <?php if("answer2" === $question->correct_answer): ?>
                                    <i class="fa-solid fa-check text-success"></i>
                                <?php elseif("answer2" === $question->my_answer->answer): ?>
                                    <i class="fa-solid fa-circle-dot"></i>
                                <?php endif; ?>
                                <label class="form-check-label" for="quiz<?php echo e($question->id); ?>2">
                                    <?php echo e($question->answer2); ?>

                                </label>
                            </div>

                            <div class="form-check">
                                <?php if("answer3" === $question->correct_answer): ?>
                                    <i class="fa-solid fa-check text-success"></i>
                                <?php elseif("answer3" === $question->my_answer->answer): ?>
                                    <i class="fa-solid fa-circle-dot"></i>
                                <?php endif; ?>
                                <label class="form-check-label" for="quiz<?php echo e($question->id); ?>3">
                                    <?php echo e($question->answer3); ?>

                                </label>
                            </div>

                            <div class="form-check">
                                <?php if("answer4" === $question->correct_answer): ?>
                                    <i class="fa-solid fa-check text-success"></i>
                                <?php elseif("answer4" === $question->my_answer->answer): ?>
                                    <i class="fa-solid fa-circle-dot"></i>
                                <?php endif; ?>
                                <label class="form-check-label" for="quiz<?php echo e($question->id); ?>4">
                                    <?php echo e($question->answer4); ?>

                                </label>
                            </div>

                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>

        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\osman\laravel-quiz\resources\views/quiz_result.blade.php ENDPATH**/ ?>