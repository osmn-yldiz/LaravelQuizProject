<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> <?php echo e($quiz->title); ?> <?php $__env->endSlot(); ?>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="float-end mb-2"><a href="<?php echo e(route('quizzes.index')); ?>" class="btn btn-primary btn-md"><i
                            class="fa-solid fa-arrow-left"></i> Geri
                        Dön</a></div>
                <div class="col-md-4">
                    <ul class="list-group">
                        <?php if($quiz->finished_at): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Son Katılım Tarihi
                                <span title="<?php echo e($quiz->finished_at); ?>"
                                      class="badge bg-secondary rounded-pill"><?php echo e($quiz->finished_at->diffForHumans()); ?></span>
                            </li>
                        <?php endif; ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Soru Sayısı
                            <span class="badge bg-secondary rounded-pill"><?php echo e($quiz->questions_count); ?></span>
                        </li>
                        <?php if($quiz->details): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Katılımcı Sayısı
                                <span class="badge bg-secondary rounded-pill"><?php echo e($quiz->details['join_count']); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Ortalama Puan
                                <span class="badge bg-secondary rounded-pill"><?php echo e($quiz->details['average']); ?></span>
                            </li>
                        <?php endif; ?>
                    </ul>

                    <?php if(count($quiz->topTen) > 0): ?>
                        <div class="card mt-3">
                            <div class="card-body">
                                <h5 class="card-title">İlk 10</h5>
                                <ol class="list-group list-group-numbered">
                                    <?php $__currentLoopData = $quiz->topTen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item">
                                            <span
                                                <?php if(auth()->user()->id === $result->user_id): ?> class="text-bg-success text-light" <?php endif; ?>><?php echo e($result->user->name); ?></span>
                                            <div class="float-end">
                                                <span
                                                    class="badge bg-success rounded-pill"><?php echo e($result->point); ?> Puan</span>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
                <div class="col-md-8">
                    <p class="card-text"><?php echo e($quiz->description); ?></p>
                    <table class="table table-bordered mt-3">
                        <thead>
                        <tr>
                            <th scope="col">Ad Soyad</th>
                            <th scope="col">Puan</th>
                            <th scope="col">Doğru</th>
                            <th scope="col">Yanlış</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $quiz->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($result->user->name); ?></td>
                                <td><?php echo e($result->point); ?></td>
                                <td><?php echo e($result->correct); ?></td>
                                <td><?php echo e($result->wrong); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\osman\laravel-quiz\resources\views/admin/quiz/show.blade.php ENDPATH**/ ?>