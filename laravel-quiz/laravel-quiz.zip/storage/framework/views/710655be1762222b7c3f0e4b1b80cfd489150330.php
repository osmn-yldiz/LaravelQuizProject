<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> <?php echo e($quiz->title); ?> <?php $__env->endSlot(); ?>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <ul class="list-group">
                        <?php if($quiz->my_rank): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Sıralama
                                <span class="badge bg-primary rounded-pill">#<?php echo e($quiz->my_rank); ?></span>
                            </li>
                        <?php endif; ?>
                        <?php if($quiz->my_result): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Puan
                                <span class="badge bg-primary rounded-pill"><?php echo e($quiz->my_result->point); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Doğru / Yanlış Sayısı
                                <div class="float-end">
                                    <span
                                        class="badge bg-success rounded-pill"><?php echo e($quiz->my_result->correct); ?> Doğru</span>
                                    <span class="badge bg-danger rounded-pill"><?php echo e($quiz->my_result->wrong); ?> Yanlış</span>
                                </div>
                            </li>
                        <?php endif; ?>
                        <?php if($quiz->finished_at): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Son Katılım Tarihi
                                <span title="<?php echo e($quiz->finished_at); ?>"
                                      class="badge bg-secondary rounded-pill"><?php echo e($quiz->finished_at->diffForHumans()); ?></span>
                            </li>
                        <?php endif; ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Soru Sayısı
                            <span class="badge bg-secondary rounded-pill"><?php echo e($quiz->questions_count); ?></span>
                        </li>
                        <?php if($quiz->details): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Katılımcı Sayısı
                                <span class="badge bg-secondary rounded-pill"><?php echo e($quiz->details['join_count']); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Ortalama Puan
                                <span class="badge bg-secondary rounded-pill"><?php echo e($quiz->details['average']); ?></span>
                            </li>
                        <?php endif; ?>
                    </ul>

                    <?php if(count($quiz->topTen) > 0): ?>
                        <div class="card mt-3">
                            <div class="card-body">
                                <h5 class="card-title">İlk 10</h5>
                                <ol class="list-group list-group-numbered">
                                    <?php $__currentLoopData = $quiz->topTen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item">
                                            <span
                                                <?php if(auth()->user()->id === $result->user_id): ?> class="text-bg-success text-light" <?php endif; ?>><?php echo e($result->user->name); ?></span>
                                            <div class="float-end">
                                                <span
                                                    class="badge bg-success rounded-pill"><?php echo e($result->point); ?> Puan</span>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
                <div class="col-md-8">
                    <p class="card-text"><?php echo e($quiz->description); ?></p>
                    <div class="d-grid gap-2 mt-2">
                        <?php if($quiz->my_result): ?>
                            <a href="<?php echo e(route('quiz.join',$quiz->slug)); ?>" class="btn btn-outline-warning btn-md"
                               style="background-color: #ffc107; color: #000000;">Quiz'i Görüntüle</a>
                        <?php elseif($quiz->finished_at > now()): ?>
                            <a href="<?php echo e(route('quiz.join',$quiz->slug)); ?>" class="btn btn-outline-primary btn-md"
                               style="background-color: #0d6efd; color: #ffffff;">Quiz'e Katıl</a>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\osman\laravel-quiz\resources\views/quiz_detail.blade.php ENDPATH**/ ?>