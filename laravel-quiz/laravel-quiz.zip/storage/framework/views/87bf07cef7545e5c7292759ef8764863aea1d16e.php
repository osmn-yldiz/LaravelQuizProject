<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Quizler <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-body">
            <div class="card-title">

                <a href="<?php echo e(route('quizzes.create')); ?>" class="btn btn-md btn-primary"><i
                        class="fa-solid fa-plus"></i>
                    Quiz Oluştur</a>

                <form action="" class="d-flex float-end" method="GET">

                    <div class="mb-3 mr-3">
                        <input type="search" class="form-control" id="exampleInputEmail1" name="title"
                               placeholder="Quiz Başlığı" value="<?php echo e(request()->get('title')); ?>">
                    </div>

                    <div class="mb-3 mr-3">
                        <select class="form-select" aria-label="Default select example" name="status"
                                onchange="this.form.submit()">
                            <option value="" selected>Quiz Durumunu Seçiniz...</option>
                            <option <?php if(request()->get('status') === 'publish'): ?> selected <?php endif; ?> value="publish">Aktif
                            </option>
                            <option <?php if(request()->get('status') === 'passive'): ?> selected <?php endif; ?> value="passive">Pasif
                            </option>
                            <option <?php if(request()->get('status') === 'draft'): ?> selected <?php endif; ?> value="draft">Taslak
                            </option>
                        </select>
                    </div>

                    <?php if(request()->get('title') || request()->get('status')): ?>
                        <div class="mb-3 mr-3">
                            <a href="<?php echo e(route('quizzes.index')); ?>" class="btn btn-secondary btn-md">Sıfırla</a>
                        </div>
                    <?php endif; ?>

                </form>

            </div>

            <table class="table table-bordered">
                <thead>
                <tr>
                    <th scope="col">Quiz</th>
                    <th scope="col">Soru Sayısı</th>
                    <th scope="col">Durum</th>
                    <th scope="col">Bitiş Tarihi</th>
                    <th scope="col">İşlemler</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($quiz->title); ?></td>
                        <td><?php echo e($quiz->questions_count); ?></td>
                        <td>
                            <?php switch($quiz->status):
                                case ('publish'): ?>
                                <?php if(!$quiz->finished_at): ?>
                                    <span class="badge rounded-pill bg-success">Aktif</span>
                                <?php elseif($quiz->finished_at > now()): ?>
                                    <span class="badge rounded-pill bg-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge rounded-pill bg-secondary">Tarihi Dolmuş</span>
                                <?php endif; ?>
                                <?php break; ?>
                                <?php case ('passive'): ?>
                                <span class="badge rounded-pill bg-danger">Pasif</span>
                                <?php break; ?>
                                <?php case ('draft'): ?>
                                <span class="badge rounded-pill bg-warning text-dark">Taslak</span>
                                <?php break; ?>
                            <?php endswitch; ?>
                        </td>
                        <td>
                            <span title="<?php echo e($quiz->finished_at); ?>">
                                <?php echo e($quiz->finished_at ? $quiz->finished_at->diffForHumans() : '-'); ?>

                            </span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('quizzes.details', $quiz->id)); ?>" class="btn btn-sm btn-secondary">
                                <i class="fa-solid fa-info"></i>
                            </a>
                            <a href="<?php echo e(route('questions.index', $quiz->id)); ?>" class="btn btn-sm btn-primary"><i
                                    class="fa-solid fa-question"></i></a>
                            <a href="<?php echo e(route('quizzes.edit', $quiz->id)); ?>" class="btn btn-sm btn-warning"><i
                                    class="fa-solid fa-pen-to-square"></i></a>
                            <a href="<?php echo e(route('quizzes.destroy',$quiz->id)); ?>" class="btn btn-sm btn-danger"><i
                                    class="fa-solid fa-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($quizzes->withQueryString()->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\osman\laravel-quiz\resources\views/admin/quiz/list.blade.php ENDPATH**/ ?>