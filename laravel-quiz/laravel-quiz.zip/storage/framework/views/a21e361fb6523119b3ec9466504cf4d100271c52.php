<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Quiz Güncelle <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-body">
            <div class="float-end mb-2"><a href="<?php echo e(route('quizzes.index')); ?>" class="btn btn-primary btn-md"><i
                        class="fa-solid fa-arrow-left"></i> Geri
                    Dön</a></div>
            <form method="POST" action="<?php echo e(route('quizzes.update',$quiz->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Quiz Başlığı</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" name="title"
                           value="<?php echo e($quiz->title); ?>">
                </div>

                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Quiz Açıklaması</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"
                              name="description"><?php echo e($quiz->description); ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Quiz Durumu</label>
                    <select class="form-select" aria-label="Default select example" name="status">
                        <option selected>Quiz Durumunu Seçiniz...</option>
                        <option <?php if($quiz->questions_count < 4): ?> disabled <?php endif; ?> <?php if($quiz->status === 'publish'): ?> selected <?php endif; ?> value="publish">Aktif
                        </option>
                        <option <?php if($quiz->status === 'passive'): ?> selected <?php endif; ?> value="passive">Pasif
                        </option>
                        <option <?php if($quiz->status === 'draft'): ?> selected <?php endif; ?> value="draft">Taslak
                        </option>
                    </select>
                </div>

                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="isFinished"
                           <?php if($quiz->finished_at): ?> checked <?php endif; ?>>
                    <label class="form-check-label" for="exampleCheck1">Bitiş Tarihi Olacak Mı?</label>
                </div>

                <div id="finishedInput" class="mb-3" <?php if(!$quiz->finished_at): ?> style="display: none" <?php endif; ?>>
                    <label class="form-label">Bitiş Tarihi</label>
                    <input type="datetime-local" class="form-control" name="finished_at"
                           <?php if($quiz->finished_at): ?> value="<?php echo e($quiz->finished_at); ?>" <?php endif; ?>>
                </div>

                <div class="d-grid gap-2 col-2 mx-auto">
                    <button class="btn btn-success btn-md" style="background-color: #198754" type="submit">Quiz Güncelle
                    </button>
                </div>

            </form>
        </div>
    </div>

     <?php $__env->slot('js', null, []); ?> 
        <script>
            $('#isFinished').change(function () {
                if ($('#isFinished').is(':checked')) {
                    $('#finishedInput').show();
                } else {
                    $('#finishedInput').hide();
                }
            });
        </script>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\osman\laravel-quiz\resources\views/admin/quiz/edit.blade.php ENDPATH**/ ?>